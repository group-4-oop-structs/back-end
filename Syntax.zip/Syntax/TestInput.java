
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rthec
 */
public class TestInput {
    public static void main(String[] args) throws IOException{
        char c = (char) System.in.read();
        
        while (c != -1){
            
        }
    }
}
